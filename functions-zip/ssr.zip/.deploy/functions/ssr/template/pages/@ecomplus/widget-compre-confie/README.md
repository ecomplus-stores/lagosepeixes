# Widget Compre & Confie

Storefront plugin for Compre & Confie to buyer review and store reliability
